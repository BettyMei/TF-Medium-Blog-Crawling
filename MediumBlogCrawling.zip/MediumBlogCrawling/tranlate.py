import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics, ttfonts
from googletrans import Translator
from googleOnlineTranslate import google_translate


src_path = 'source_data/'
tar_path = 'result_data/'

# 注册字体
pdfmetrics.registerFont(ttfonts.TTFont('yahei', 'C:\Windows\Fonts\msyh.ttc'))

# 获取文件名
def get_file_names(directory):
    file_names = []
    for file_name in os.listdir(directory):
        if os.path.isfile(os.path.join(directory, file_name)):
            file_names.append(file_name)
    return file_names


# 读数据
def file_read(path):
    with open(path, "r", encoding="utf-8") as f:
        data = f.readlines()
    return data


# 写数据
def file_write(path, data):
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)


"""
使用Google Translate API来实现英文到中文的翻译，需要注册API key
"""
# english_text = "This is a sample English text that we want to translate into Chinese."
# chinese_text = r"这是一段简单的英文文章"
# # 生成PDF文件
# pdf_file = "result_data/translated_text.pdf"
# c = canvas.Canvas(pdf_file, pagesize=letter)
# # c.drawString(100, 750, "English Text:")
# c.drawString(100, 730, english_text)
# # c.drawString(100, 700, "Chinese Translation:")
# c.setFont('yahei', 10)  # 设置字体及大小
# c.drawString(100, 680, chinese_text)
# c.save()
# print(f"PDF文件已生成：{pdf_file}")


# 使用Google Translate API进行翻译
# def google_translate(english_text):
#     translator = Translator()
#     chinese_text = translator.translate(english_text, src='en', dest='zh-cn').text
#     print(chinese_text)
#     return chinese_text


paths = get_file_names(src_path)
for p in paths:
    en_txt = file_read(src_path+p)
    cn_txt = google_translate(en_txt)
    # 生成PDF文件
    pdf_file = tar_path+"translated_text.pdf"
    c = canvas.Canvas(pdf_file, pagesize=letter)
    # c.drawString(100, 750, "English Text:")
    c.drawString(100, 730, en_txt)
    # c.drawString(100, 700, "Chinese Translation:")
    c.setFont('yahei', 10)  # 设置字体及大小
    c.drawString(100, 680, cn_txt)
    c.save()
    print(f"PDF文件已生成：{pdf_file}")


